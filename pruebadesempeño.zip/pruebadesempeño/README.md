## Overview
This project was developed to address the challenge of organizing financial transaction data coming from Fintech platforms such as **Nequi** and **Daviplata**.  
Previously, the information was scattered across multiple Excel spreadsheets, making it difficult to manage and analyze.  

The solution introduces:
- A **structured relational database** built with SQL.
- A **bulk data import process** from CSV files.
- A **CRUD API** for managing one main entity in the system.
- **Advanced SQL queries** to provide meaningful business insights.
- A **minimal web interface** to perform CRUD operations.

---

## Project Goals
The main objectives are to:
- Apply **data normalization** up to the third normal form (1NF, 2NF, 3NF).
- Create a relational diagram that represents the normalized structure.
- Build the SQL database according to the diagram.
- Import data from CSV into the database.
- Develop a CRUD feature for one specific entity.
- Write advanced SQL queries for reporting needs.

---

## Tools and Technologies
- **Database:** MySQL or MariaDB
- **Backend:** Node.js with Express
- **Frontend:** HTML + CSS with Bootstrap, Tailwind, or Bulma
- **Data import:** Local CSV loading
- **Testing:** Postman
- **Diagram tool:** draw.io or equivalent

---


---

## Data Normalization Process
1. **1NF:** Ensure there are no repeating groups and each field holds a single value.
2. **2NF:** Remove partial dependencies from composite keys.
3. **3NF:** Eliminate transitive dependencies between non-key attributes.

**Output:** A relational model in image or PDF format showing all tables, columns, and relationships.

---

## Database Setup
- Naming convention for database:
```

prueba_2_JhonRojas_VanRossum

````
- All identifiers (tables, columns) must be in **English**.
- Include:
- Primary keys
- Foreign keys
- Constraints (NOT NULL, UNIQUE, etc.)
- Submit a `.sql` file with the full DDL.

---

## Bulk Data Import
- Convert the original Excel (`.xlsx`) to `.csv`.
- Load the CSV into the database **locally**:
- Using a manual SQL script, or
- Through a frontend button triggering the local script.
- The steps must be clearly described in this document.

---

## CRUD Implementation
- Manage one database entity using Create, Read, Update, and Delete.
- Validate inputs before inserting or updating.
- Provide access via an Express API.
- The dashboard must connect to the API.

---

## Advanced SQL Queries (via Postman)
1. **Total amount paid by each client**  
 Aggregates all payments per customer.
2. **Unpaid invoices with client and transaction details**  
 Lists pending invoices along with customer information and linked transactions.
3. **Transactions per platform**  
 Retrieves all transactions from a chosen platform, with related customer and invoice data.

---

## Postman Requirements
- Include all CRUD endpoints.
- Include endpoints for the three advanced queries.
- Export and attach the `.json` file in the repository.

---

## Running the Project
1. **Clone repository**
 ```bash
 git clone <repo-url>
 cd project-folder
````

2. **Install dependencies**

   ```bash
   npm install
   ```
3. **Set up database**

   * Run the `.sql` file in MySQL to create tables.
4. **Import CSV data**

   * Execute the provided import script or use the frontend button.
5. **Start the backend**

   ```bash
   npm start
   ```
6. **Access dashboard**

   * Go to `http://localhost:<port>`

---

## Deliverables Checklist

* Relational model (image/PDF)
* SQL DDL script (`.sql`)
* CSV dataset
* Backend code (CRUD API)
* Frontend dashboard
* Postman collection
* README.md

---

## Author

* **Name:** Jhon Rojas
* **Clan:** Van Rosssum
* **Email:** jfrojas1997@gmail.com