const APP_URL = "http://localhost:3000/"
const tbody_pacients = document.getElementById("tbody_users");

const addButton = document.getElementById("addButton");
document.getElementById('upload_users').addEventListener('click', async () => {
    try {
      const res = await fetch(APP_URL +'upload-users', {
        method: 'POST'
      });
      const data = await res.json();
      alert(`${data.message}`);
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });

//fornt para eliminar usuario este id llega de el index que lo guarda para usarlo en la eliminacion y modificacion 

function deleteData(id) {
  if (confirm("¿Seguro que quieres eliminar este usuario?")) {
    fetch(APP_URL + "users/" + id, {
      method: "DELETE"
    })
    .then(response => {
      if (!response.ok) throw new Error("Error al eliminar usuario");
      return response.json();
    })
    .then(data => {
      alert(data.mensaje);
      location.reload();
    })
    .catch(error => {
      console.error(error);
      alert("Hubo un problema al eliminar el usuario");
    });
  }
}

//


function updateData(id) {
  fetch(APP_URL + 'users/' + id)
    .then(res => {
      if (!res.ok) throw new Error('No se pudo obtener el usuario');
      return res.json();
    })
    .then(user => {
      document.getElementById("user_document").value = user.id_document;
      document.getElementById("user_name").value = user.name;
      document.getElementById("user_address").value = user.address;
      document.getElementById("user_city").value = user.city;
      document.getElementById("user_phone").value = user.phone;
      document.getElementById("user_email").value = user.email;

      document.getElementById('courseModalLabel').textContent = 'Editar usuario';

      const modalEl = document.getElementById('courseModal');
      const modal = new bootstrap.Modal(modalEl);
      modal.show();

      const addButton = document.getElementById('addButton');
      addButton.textContent = 'Actualizar';

      addButton.replaceWith(addButton.cloneNode(true));
      const newAddButton = document.getElementById('addButton');

      newAddButton.addEventListener('click', async () => {
      
      const name = document.getElementById("user_name").value.trim();
      const address = document.getElementById("user_address").value.trim();
      const city = document.getElementById("user_city").value.trim();
      const phone = document.getElementById("user_phone").value.trim();
      const email = document.getElementById("user_email").value.trim();


        try {
          const res = await fetch(APP_URL + 'update-user/' + id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, address, city, phone, email })
          });

          if (!res.ok) throw new Error('Error al actualizar paciente');

          alert('Paciente actualizado correctamente');
          modal.hide();
          location.reload();
        } catch (error) {
          console.error(error);
          alert('Error al actualizar paciente');
        }
      });
    })
    .catch(err => {
      console.error(err);
      alert('No se pudo cargar el paciente para editar');
    });
}



  (async function index() {
    const res = await fetch (APP_URL+"users");
    const data = await res.json();
    console.log("GET:", data);
    tbody_users.innerHTML = "";
    data.forEach(user => {
      tbody_users.innerHTML += `
      <tr>
        <td>${user.id_document}</td>
        <td>${user.name}</td>
        <td>${user.address}</td>
        <td>${user.city}</td>
        <td>${user.phone}</td>
        <td>${user.email}</td>
        <td>
             <button class="btn btn-sm btn-warning" onclick="updateData(${user.id_document})">update</button>
            <button class="btn btn-sm btn-danger" onclick="deleteData(${user.id_document})">Eliminar</button>

        </td>
    </tr>
      `
      
    });
    
  })()
  
async function store() {
  
  try {
  const user_document = document.getElementById("user_document").value.trim();
  const user_name = document.getElementById("user_name").value.trim();
  const user_address = document.getElementById("user_address").value.trim();
  const user_city = document.getElementById("user_city").value.trim();
  const user_phone = document.getElementById("user_phone").value.trim();
  const user_email = document.getElementById("user_email").value.trim();

  if (!user_document || !user_name|| !user_address|| !user_city|| !user_phone|| !user_email) {
    alert("Todos los campos son obligatorios");
    return;
  }
  const resUsers = await fetch(APP_URL + "users");
  const users = await resUsers.json();

  const existEmail = users.some(user_existed => user_existed.email.toLowerCase() === user_email.toLowerCase() );
  if (existEmail) {
    alert("El email ya está registrado");
    return;
  }

   

  const res = await fetch(APP_URL + 'upload-user', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
    id_document: user_document,
    name: user_name,
    address:user_address,
    city:user_city,
    phone:user_phone,
    email: user_email
    })
  });

  await res.json();


  const modalEl = document.getElementById('courseModal');
  const modal = bootstrap.Modal.getInstance(modalEl);
  modal.hide();

  location.reload();

} catch (error) {
  console.error('Error en POST:', error);
}
}

addButton?.addEventListener("click", store);


