const APP_URL = "http://localhost:3000/"
const tbody_locations = document.getElementById("tbody_locations");

const addButton = document.getElementById("addButton");
document.getElementById('upload_loans').addEventListener('click', async () => {
    try {
      const res = await fetch(APP_URL +'upload-loans', {
        method: 'POST'
      });
      const data = await res.json();
      alert(`${data.message}`);
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });



(async function index() {
    const res = await fetch (APP_URL+"loans");
    const data = await res.json();
    console.log("GET:", data);
    tbody_loans.innerHTML = "";
    data.forEach(loan => {
      tbody_loans.innerHTML += `
      <tr>
        <td>${loan.id_loan}</td>
        <td>${loan.loan_days}</td>
        <td>${loan.loan_date}</td>
        <td>${loan.loan_state}</td>
        <td>${loan.loan_type}</td>
        <td>${loan.booking_platform}</td>
        <td>${loan.document}</td>
        <td>
             <button class="btn btn-sm btn-warning" onclick="updateData('${loan.id_loan}')">update</button>
            <button class="btn btn-sm btn-danger" onclick="deleteData('${loan.id_loan}')">Eliminar</button>

        </td>
    </tr>
      `
      
    });
    
  })()


  async function store() {
  
  try {
    const loan_id = document.getElementById("loan_id").value.trim();
    const loan_date = document.getElementById("loan_date").value.trim();
    const loan_days = document.getElementById("loan_days").value.trim();
    const loan_state = document.getElementById("loan_state").value.trim();
    const loan_type = document.getElementById("loan_type").value.trim();
    const loan_platform = document.getElementById("loan_platform").value.trim();
    const loan_document = document.getElementById("loan_document").value.trim();

  if (!loan_id || !loan_date || !loan_days || !loan_state || !loan_type || !loan_platform || !loan_document ) {
    alert("Todos los campos son obligatorios");
    return;
  }


  const resUsers = await fetch(APP_URL + "loans");
  const users = await resUsers.json();

  const existe = users.some(user => user.id_loan.toLowerCase() === loan_id.toLowerCase());
  if (existe) {
    alert("El prestamo ya está registrado");
    return;
  }

  const res = await fetch(APP_URL + 'upload-loan', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      id_loan: loan_id,
        loan_days: loan_days,
        loan_date: loan_date,
        loan_state: loan_state,
        loan_type: loan_type,
        booking_platform: loan_platform,
        document: loan_document

    })
  });

  await res.json();


  const modalEl = document.getElementById('courseModal');
  const modal = bootstrap.Modal.getInstance(modalEl);
  modal.hide();

  location.reload();

} catch (error) {
  console.error('Error en POST:', error);
}
}

addButton?.addEventListener("click", store);


function deleteData(id) {
  if (confirm("¿Seguro que quieres eliminar esta sede?")) {
    fetch(APP_URL + "loans/" + id, {
      method: "DELETE"
    })
    .then(response => {
      if (!response.ok) throw new Error("Error al eliminar la sede");
      return response.json();
    })
    .then(data => {
      alert(data.mensaje);
      location.reload();
    })
    .catch(error => {
      console.error(error);
      alert("Hubo un problema al eliminar el location");
    });
  }
}


function updateData(id) {
  fetch(APP_URL + 'loans/' + id)
    .then(res => {
      if (!res.ok) throw new Error('No se pudo obtener el prestamo');
      return res.json();
    })
    .then(loan => {
    document.getElementById("loan_id").value = loan.id_loan;
    document.getElementById("loan_date").value = loan.loan_date;
    document.getElementById("loan_days").value = loan.loan_days;
    document.getElementById("loan_state").value = loan.loan_state;
    document.getElementById("loan_type").value = loan.loan_type;
    document.getElementById("loan_platform").value = loan.booking_platform;
    document.getElementById("loan_document").value =loan.document;


      document.getElementById('courseModalLabel').textContent = 'Editar prestamo';

      const modalEl = document.getElementById('courseModal');
      const modal = new bootstrap.Modal(modalEl);
      modal.show();

      const addButton = document.getElementById('addButton');
      addButton.textContent = 'Actualizar';

      addButton.replaceWith(addButton.cloneNode(true));
      const newAddButton = document.getElementById('addButton');

      newAddButton.addEventListener('click', async () => {
        const loan_date = document.getElementById("loan_date").value.trim();
        const loan_days = document.getElementById("loan_days").value.trim();
        const loan_state = document.getElementById("loan_state").value.trim();
        const loan_type = document.getElementById("loan_type").value.trim();
        const booking_platform = document.getElementById("loan_platform").value.trim();
        const document = document.getElementById("loan_document").value.trim();

        // if (!name) {
        //   alert('Todos los campos son obligatorios');
        //   return;
        // }

        try {
          const res = await fetch(APP_URL + 'update-loan/' + id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({loan_date, loan_days, loan_state, loan_type, booking_platform, document})
          });

          if (!res.ok) throw new Error('Error al actualizar paciente');

          alert('Paciente actualizado correctamente');
          modal.hide();
          location.reload();
        } catch (error) {
          console.error(error);
          alert('Error al actualizar paciente');
        }
      });
    })
    .catch(err => {
      console.error(err);
      alert('No se pudo cargar el paciente para editar');
    });
}
