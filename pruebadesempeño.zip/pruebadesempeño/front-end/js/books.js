const APP_URL = "http://localhost:3000/"
const tbody_pacients = document.getElementById("tbody_books");

const addButton = document.getElementById("addButton");
document.getElementById('upload_books').addEventListener('click', async () => {
    try {
      const res = await fetch(APP_URL +'upload-books', {
        method: 'POST'
      });
      const data = await res.json();
      alert(`${data.message}`);
    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  });


(async function index() {
    const res = await fetch (APP_URL+"books");
    const data = await res.json();
    console.log("GET:", data);
    tbody_books.innerHTML = "";
    data.forEach(book => {
      tbody_books.innerHTML += `
      <tr>
        <td>${book.isbn}</td>
        <td>${book.book_name}</td>
        <td>${book.book_author}</td>
        <td>${book.publication_year}</td>
        <td>
             <button class="btn btn-sm btn-warning" onclick="updateData(${book.isbn})">update</button>
            <button class="btn btn-sm btn-danger" onclick="deleteData(${book.isbn})">Eliminar</button>

        </td>
    </tr>
      `
      
    });
    
  })()

async function store() {
  
  try {
  const pacient_name = document.getElementById("pacient_name").value.trim();

  if (!pacient_name) {
    alert("Todos los campos son obligatorios");
    return;
  }


  const resUsers = await fetch(APP_URL + "doctors");
  const users = await resUsers.json();

  const existe = users.some(user => user.name.toLowerCase() === pacient_name.toLowerCase());
  if (existe) {
    alert("El doctor ya está registrado");
    return;
  }

  const res = await fetch(APP_URL + 'upload-doctor', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: pacient_name,
    })
  });

  await res.json();


  const modalEl = document.getElementById('courseModal');
  const modal = bootstrap.Modal.getInstance(modalEl);
  modal.hide();

  location.reload();

} catch (error) {
  console.error('Error en POST:', error);
}
}

addButton?.addEventListener("click", store);

function deleteData(id) {
  if (confirm("¿Seguro que quieres eliminar este doctor?")) {
    fetch(APP_URL + "doctors/" + id, {
      method: "DELETE"
    })
    .then(response => {
      if (!response.ok) throw new Error("Error al eliminar doctor");
      return response.json();
    })
    .then(data => {
      alert(data.mensaje);
      location.reload();
    })
    .catch(error => {
      console.error(error);
      alert("Hubo un problema al eliminar el doctor");
    });
  }
}

function updateData(id) {
  fetch(APP_URL + 'doctors/' + id)
    .then(res => {
      if (!res.ok) throw new Error('No se pudo obtener el doctor');
      return res.json();
    })
    .then(paciente => {
      document.getElementById('pacient_name').value = paciente.name;


      document.getElementById('courseModalLabel').textContent = 'Editar doctor';

      const modalEl = document.getElementById('courseModal');
      const modal = new bootstrap.Modal(modalEl);
      modal.show();

      const addButton = document.getElementById('addButton');
      addButton.textContent = 'Actualizar';

      addButton.replaceWith(addButton.cloneNode(true));
      const newAddButton = document.getElementById('addButton');

      newAddButton.addEventListener('click', async () => {
        const name = document.getElementById('pacient_name').value.trim();

        if (!name) {
          alert('Todos los campos son obligatorios');
          return;
        }

        try {
          const res = await fetch(APP_URL + 'update-doctor/' + id, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name})
          });

          if (!res.ok) throw new Error('Error al actualizar paciente');

          alert('Paciente actualizado correctamente');
          modal.hide();
          location.reload();
        } catch (error) {
          console.error(error);
          alert('Error al actualizar paciente');
        }
      });
    })
    .catch(err => {
      console.error(err);
      alert('No se pudo cargar el paciente para editar');
    });
}

