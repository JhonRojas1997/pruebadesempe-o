create table users (
id_document bigint primary key not null,
name varchar(120) not null,
address varchar(120) not NULL,
city varchar(80) not null,
phone varchar(30) not null,
email varchar(120) not null unique
)

create table loans(
id_loan varchar(45) primary key not null,
loan_days int not null,
loan_date varchar(120) not null,
loan_state enum("pendiente", "retrasado", "completado"),
loan_type enum("prestamo a domicilio", "prestamo interbibliotecario", "consulta en sala"),
booking_platform enum("webbiblioteca", "appbiblioteca"),
document bigint,
foreign key (document) references users(id_document)
);

create table books(
isbn varchar(120) primary key not null,
book_name varchar(120) unique not null,
book_author varchar(120) not null,
publication_year varchar(10) not null
)

create table devolutions(
id_devolution int primary key auto_increment,
fine_generated date null,
fine_paid int not null,
loan varchar(45) ,
foreign key (loan) references loans(id_loan)
)