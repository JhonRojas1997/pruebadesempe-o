const fs = require('fs');
const csv = require('csv-parser');
require('dotenv').config();
const mysql = require('mysql2/promise');

async function UsersCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const users = [];
    fs.createReadStream('users.csv')
      .pipe(csv())
      .on('data', (data) => {
        users.push(data);
      })
      .on('end', async () => {
        for (const user of users) {
          const query = `
            INSERT IGNORE INTO users(id_document, name, address, city, phone, email) 
            VALUES (?, ?, ?, ?, ?, ?)
          `;
          const values = [user.id_document, user.name, user.address, user.city, user.phone, user.email];
          await client.execute(query, values);
        }

        console.log('Usuarios cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando usuarios:', err.message || err);
    if (client) await client.end();
  }
}



async function BooksCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const books = [];
    fs.createReadStream('books.csv')
      .pipe(csv())
      .on('data', (data) => {
        books.push(data);
      })
      .on('end', async () => {
        for (const book of books) {
          const query = `
            INSERT IGNORE INTO books(isbn, book_name, book_author, publication_year) 
            VALUES (?, ?, ?, ?)
          `;
          const values = [book.isbn, book.book_name, book.book_author, book.publication_year];
          await client.execute(query, values);
        }

        console.log('Libros cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando Libros:', err.message || err);
    if (client) await client.end();
  }
}




async function LoansCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const loans = [];
    fs.createReadStream('loans.csv')
      .pipe(csv())
      .on('data', (data) => {
        loans.push(data);
      })
      .on('end', async () => {
        for (const loan of loans) {
          const query = `
            INSERT IGNORE INTO loans(id_loan,loan_days, loan_date,loan_state,loan_type,booking_platform,document) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
          `;
          const values = [loan.id_loan,loan.loan_days,loan.loan_date,loan.loan_state,loan.loan_type,loan.booking_platform,loan.document];
          await client.execute(query, values);
        }

        console.log('Prestamos cargados exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando prestamos:', err.message || err);
    if (client) await client.end();
  }
}

async function DevolutionsCSV() {
  let client;

  try {
    client = await mysql.createConnection({
      host: process.env.HOST,
      user: process.env.DB_USER,
      password: process.env.PASSWORD,
      database: process.env.DATABASE,
      port: process.env.PORT
    });


    const devolutions = [];
    fs.createReadStream('devolutions.csv')
      .pipe(csv())
      .on('data', (data) => {
        devolutions.push(data);
      })
      .on('end', async () => {
        for (const devolution of devolutions) {
          const query = `
            INSERT IGNORE INTO devolutions(devolution_date, fine_generated, fine_paid, id_loan) 
            VALUES (?, ?, ?, ?)
          `;
          const values = [devolution.devolution_date, devolution.fine_generated, devolution.fine_paid, devolution.id_loan];
          await client.execute(query, values);
        }

        console.log('devoluciones cargadas exitosamente.');
        await client.end();
      });

  } catch (err) {
    console.error('Error cargando devoluciones:', err.message || err);
    if (client) await client.end();
  }
}

module.exports = {
  UsersCSV,
  BooksCSV,
  LoansCSV,
  DevolutionsCSV

};