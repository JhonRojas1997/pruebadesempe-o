//librerias cosas necesarias
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
//funciones carga csv
const {
  UsersCSV,
  BooksCSV,
  LoansCSV,
  DevolutionsCSV
} = require('./csvapp');

const app = express();
app.use(express.json());

app.use(cors());
//Conexion a base de datos que vienen del env
const pool = mysql.createPool({
  host: process.env.HOST,
  user: process.env.DB_USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
  port: process.env.PORT
});

//Post que llama a la funcion csv

app.post('/upload-users', async (req, res) => {
  UsersCSV();
  res.json({ message: 'Se ha iniciado la carga' });
});

app.post('/upload-devolutions', async (req, res) => {
  DevolutionsCSV();
  res.json({ message: 'Se ha iniciado la carga' });
});

//post que obtiene todos los datos de usuarios

app.get("/users", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM users");
    return res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Usuarios no obtenidos" });
  }
});

app.get("/books", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM books");
    return res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "libros no obtenidos" });
  }
});
//delete que elimina usuario con el id que viene del front

app.delete('/users/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM users WHERE id_document = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'No se encontro el usuario' });
    }

    res.json({ mensaje: 'Usuario eliminado correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar el Usuario' });
  }
});

// agrega nuevos datos a users  post

app.post('/upload-user', async (req, res) => {
  const { id_document, name, address, city, phone, email } = req.body;

  try {
    const [result] = await pool.query(
      `INSERT IGNORE INTO users(id_document, name, address, city, phone, email) 
            VALUES (?, ?, ?, ?, ?, ?)`,
      [id_document, name, address, city, phone, email]
    );
    if (result.affectedRows > 0) {
      res.status(201).json({
        id_document,
        name,
        address,
        city,
        phone,
        email
      });
    } else {
      res.status(200).json({ message: 'Usuario ya existente o no insertado' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al insertar el usuario' });
  }
});



app.put('/update-user/:id', async (req, res) => {
  const { id } = req.params;
  const {name, address, city, phone, email } = req.body;

  try {
    const [result] = await pool.query(
      `UPDATE users 
       SET name = ?, address = ?, city = ?, phone = ?, email = ?
       WHERE id_document = ?`,
      [name, address, city, phone, email, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    res.json({ mensaje: 'usuario actualizado correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el usuario' });
  }
});











app.get('/users/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE id_document = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener el Usuario' });
  }
});

app.post('/upload-books', async (req, res) => {
  BooksCSV();
  res.json({ message: 'Proceso de carga inciado' });
});



app.post('/upload-loans', async (req, res) => {
  LoansCSV();
  res.json({ message: 'Proceso de carga inciado' });
});


app.get("/loans", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM loans");
    return res.json(rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener loans" });
  }
});


app.post('/upload-loan', async (req, res) => {
  const { id_loan,loan_days, loan_date,loan_state,loan_type,booking_platform,document } = req.body;

  try {
    const [result] = await pool.query(
      `INSERT IGNORE INTO loans(id_loan,loan_days, loan_date,loan_state,loan_type,booking_platform,document) 
            VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [id_loan,loan_days, loan_date,loan_state,loan_type,booking_platform,document]
    );
    if (result.affectedRows > 0) {
      res.status(201).json({
        id_loan,
        loan_days,
        loan_date,
        loan_state,
        loan_type,
        booking_platform,
        document

      });
    } else {
      res.status(200).json({ message: 'prestamo ya existente o no insertada' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al insertar el prestamo' });
  }
});


app.delete('/loans/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const [result] = await pool.query('DELETE FROM loans WHERE id_loan = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'prestamo no encontrado' });
    }

    res.json({ mensaje: 'prestamo eliminado correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al eliminar el prestamo' });
  }
});


app.put('/update-loan/:id', async (req, res) => {
  const { id } = req.params;
  const { loan_days, loan_date,loan_state,loan_type,booking_platform,document } = req.body;

  try {
    const [result] = await pool.query(
      `UPDATE loans 
       SET loan_days = ?, loan_date = ?, loan_state = ?, loan_type = ?, booking_platform = ?, document = ?
       WHERE id_loan = ?`,
      [loan_days, loan_date,loan_state,loan_type,booking_platform,document, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'prestamo no encontrado' });
    }

    res.json({ mensaje: 'prestamo actualizado correctamente' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al actualizar el Doctor' });
  }
});

app.get('/loans/:id', async (req, res) => {
  const { id } = req.params;

  try {
    const [rows] = await pool.query(
      'SELECT * FROM loans WHERE id_loan = ?',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Doctor no encontrado' });
    }

    res.json(rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Error al obtener el doctor' });
  }
});


app.post('/upload-specialities', async (req, res) => {
  cargarspecialitiesDesdeCSV();
  res.json({ message: 'Proceso de carga inciado' });
});





app.listen(3000, () => console.log('Servidor corriendo en http://localhost:3000'));

